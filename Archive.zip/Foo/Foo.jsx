import React from 'react';

class Foo extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div className="foo">Hello Foo</div>
    )
  }
}

export default Foo;